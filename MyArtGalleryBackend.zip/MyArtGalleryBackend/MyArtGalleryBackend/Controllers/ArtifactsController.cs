﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MyArtGalleryBackend.Models;
using MyArtGalleryBackend.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MyArtGalleryBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ArtifactsController : ControllerBase
    {
        private readonly IArtifactRepository _repository;

        public ArtifactsController(IArtifactRepository repository)
        {
            _repository = repository;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Artifact>>> GetArtifacts()
        {
            var artifacts = await _repository.GetAll();
            return Ok(artifacts);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Artifact>> GetArtifact(int id)
        {
            var artifact = await _repository.GetById(id);
            if (artifact == null)
            {
                return NotFound();
            }
            return Ok(artifact);
        }
        
        [Authorize(Policy = "AdminOnly")]
        [HttpPost]
        public async Task<ActionResult<Artifact>> PostArtifact(Artifact artifact)
        {
            await _repository.Add(artifact);
            return CreatedAtAction(nameof(GetArtifact), new { id = artifact.Id }, artifact);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutArtifact(int id, Artifact artifact)
        {
            if (id != artifact.Id)
            {
                return BadRequest();
            }

            await _repository.Update(artifact);
            return NoContent();
        }

        [Authorize(Policy = "AdminOnly")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteArtifact(int id)
        {
            var artifact = await _repository.Delete(id);
            if (artifact == null)
            {
                return NotFound();
            }

            return NoContent();
        }

        [HttpGet("artist/{artistId}")]
        public async Task<ActionResult<IEnumerable<Artifact>>> GetArtifactsByArtist(int artistId)
        {
            var artifacts = await _repository.GetByArtistId(artistId);
            return Ok(artifacts);
        }
    }
}
