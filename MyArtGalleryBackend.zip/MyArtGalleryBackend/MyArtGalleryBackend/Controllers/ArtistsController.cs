﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MyArtGalleryBackend.Models;
using MyArtGalleryBackend.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MyArtGalleryBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ArtistsController : ControllerBase
    {
        private readonly ArtistRepository _repository;

        public ArtistsController(ArtistRepository repository)
        {
            _repository = repository;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Artist>>> GetArtists()
        {
            var artists = await _repository.GetAll();
            return Ok(artists);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Artist>> GetArtist(int id)
        {
            var artist = await _repository.GetById(id);
            if (artist == null)
            {
                return NotFound();
            }
            return Ok(artist);
        }

        [Authorize(Policy = "AdminOnly")]
        [HttpPost]
        public async Task<ActionResult<Artist>> PostArtist(Artist artist)
        {
            await _repository.Add(artist);
            return CreatedAtAction(nameof(GetArtist), new { id = artist.Id }, artist);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutArtist(int id, Artist artist)
        {
            if (id != artist.Id)
            {
                return BadRequest();
            }

            try
            {
                await _repository.Update(artist);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!await ArtistExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        private async Task<bool> ArtistExists(int id)
        {
            return await _repository.GetById(id) != null;
        }

        [Authorize(Policy = "AdminOnly")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteArtist(int id)
        {
            var artist = await _repository.Delete(id);
            if (artist == null)
            {
                return NotFound();
            }

            return NoContent();
        }
    }
}
