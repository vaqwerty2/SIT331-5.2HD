using System.Collections.Generic;
using System.Threading.Tasks;
using MyArtGalleryBackend.Models;

namespace MyArtGalleryBackend.Repositories
{
    public interface IUserRepository : IRepository<User>
    {
        Task<IEnumerable<User>> GetByRole(string role);
        Task<User> GetByEmail(string email);
    }
}
