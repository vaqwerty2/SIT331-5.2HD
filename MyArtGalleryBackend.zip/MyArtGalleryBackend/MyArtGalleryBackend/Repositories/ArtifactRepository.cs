using MyArtGalleryBackend.Data;
using MyArtGalleryBackend.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyArtGalleryBackend.Repositories
{
    public class ArtifactRepository : IArtifactRepository
    {
        private readonly ApplicationDbContext _context;

        public ArtifactRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Artifact>> GetAll()
        {
            return await _context.Artifacts.Include(a => a.Artist).ToListAsync();
        }

        public async Task<Artifact> GetById(int id)
        {
            return await _context.Artifacts.Include(a => a.Artist).FirstOrDefaultAsync(a => a.Id == id);
        }

        public async Task<Artifact> Add(Artifact artifact)
        {
            _context.Artifacts.Add(artifact);
            await _context.SaveChangesAsync();
            return artifact;
        }

        public async Task<Artifact> Update(Artifact artifact)
        {
            _context.Artifacts.Update(artifact);
            await _context.SaveChangesAsync();
            return artifact;
        }

        public async Task<Artifact> Delete(int id)
        {
            var artifact = await _context.Artifacts.FindAsync(id);
            if (artifact != null)
            {
                _context.Artifacts.Remove(artifact);
                await _context.SaveChangesAsync();
            }
            return artifact;
        }

        public async Task<IEnumerable<Artifact>> GetByArtistId(int artistId)
        {
            return await _context.Artifacts.Where(a => a.ArtistId == artistId).Include(a => a.Artist).ToListAsync();
        }
    }
}
