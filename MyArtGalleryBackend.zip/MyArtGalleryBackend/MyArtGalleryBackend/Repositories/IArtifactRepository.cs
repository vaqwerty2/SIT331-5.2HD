using MyArtGalleryBackend.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MyArtGalleryBackend.Repositories
{
    public interface IArtifactRepository : IRepository<Artifact>
    {
        Task<IEnumerable<Artifact>> GetByArtistId(int artistId);
    }
}
