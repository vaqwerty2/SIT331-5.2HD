﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MyArtGalleryBackend.Models
{
    public class Artist
    {
        public int Id { get; set; }
        
        [Required]
        [Column("firstname")]
        public string FirstName { get; set; }

        [Required]
        [Column("lastname")]
        public string LastName { get; set; }

        [Required]
        [Column("dob")]
        public DateTime Dob { get; set; }

        [Column("genre")]
        public string Genre { get; set; }

        [Column("country")]
        public string Country { get; set; }

        [Column("createddate")]
        public DateTime CreatedDate { get; set; }

        [Column("latestissuedate")]
        public DateTime? LatestIssueDate { get; set; }
    }
}
