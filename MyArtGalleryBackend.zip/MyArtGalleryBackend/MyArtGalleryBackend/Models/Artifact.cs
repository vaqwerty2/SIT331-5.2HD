﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MyArtGalleryBackend.Models
{
    public class Artifact
    {
        public int Id { get; set; }

        [Required]
        [Column("name")]
        public string Name { get; set; }

        [Column("description")]
        public string Description { get; set; }

        [Required]
        [Column("artistid")]
        public int ArtistId { get; set; }

        [Column("category")]
        public string Category { get; set; }

        [Column("createddate")]
        public DateTime CreatedDate { get; set; }

        [ForeignKey("ArtistId")]
        public Artist Artist { get; set; }
    }
}
