using System;
using System.Security.Claims;
using System.Text;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MyArtGalleryBackend.Models;
using MyArtGalleryBackend.Repositories;
using BCrypt.Net;

public class BasicAuthenticationHandler : AuthenticationHandler<AuthenticationSchemeOptions>
{
    private readonly IUserRepository _userRepository;

    public BasicAuthenticationHandler(
        IOptionsMonitor<AuthenticationSchemeOptions> options,
        ILoggerFactory loggerFactory,
        UrlEncoder encoder,
        ISystemClock clock,
        IUserRepository userRepository) :
        base(options, loggerFactory, encoder, clock)
    {
        _userRepository = userRepository;
    }

    protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        Response.Headers.Add("WWW-Authenticate", @"Basic realm=""MyArtGallery""");

        if (!Request.Headers.ContainsKey("Authorization"))
        {
            Response.StatusCode = 401;
            return AuthenticateResult.Fail("Unauthorized");
        }

        var authHeader = Request.Headers["Authorization"].ToString();
        if (string.IsNullOrEmpty(authHeader) || !authHeader.StartsWith("Basic ", StringComparison.OrdinalIgnoreCase))
        {
            Response.StatusCode = 401;
            return AuthenticateResult.Fail("Unauthorized");
        }

        var token = authHeader.Substring("Basic ".Length).Trim();
        byte[] bytes;
        try
        {
            bytes = Convert.FromBase64String(token);
        }
        catch
        {
            Response.StatusCode = 401;
            return AuthenticateResult.Fail("Invalid Base64 string");
        }

        string credentials;
        try
        {
            credentials = Encoding.UTF8.GetString(bytes);
        }
        catch
        {
            Response.StatusCode = 401;
            return AuthenticateResult.Fail("Invalid UTF-8 string");
        }

        var parts = credentials.Split(':', 2);
        if (parts.Length != 2)
        {
            return AuthenticateResult.Fail("Invalid credentials format");
        }

        string email = parts[0];
        string password = parts[1];

        var user = await _userRepository.GetByEmail(email);
        if (user == null)
        {
            Response.StatusCode = 401;
            return AuthenticateResult.Fail("Invalid email or password");
        }

        bool isPasswordValid = BCrypt.Net.BCrypt.Verify(password, user.PasswordHash);
        if (!isPasswordValid)
        {
            Response.StatusCode = 401;
            return AuthenticateResult.Fail("Invalid email or password");
        }

        var claims = new[]
        {
            new Claim(ClaimTypes.Name, $"{user.FirstName} {user.LastName}"),
            new Claim(ClaimTypes.Email, user.Email),
            new Claim(ClaimTypes.Role, user.Role)
        };

        var identity = new ClaimsIdentity(claims, Scheme.Name);
        var claimsPrincipal = new ClaimsPrincipal(identity);
        var authTicket = new AuthenticationTicket(claimsPrincipal, Scheme.Name);

        return AuthenticateResult.Success(authTicket);
    }
}
