﻿using Microsoft.EntityFrameworkCore;
using MyArtGalleryBackend.Models;

namespace MyArtGalleryBackend.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Artist> Artists { get; set; }
        public DbSet<Artifact> Artifacts { get; set; }
        public DbSet<User> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Artists table configuration
            modelBuilder.Entity<Artist>(entity =>
            {
                entity.ToTable("artists");
                entity.Property(e => e.Id).HasColumnName("id");
                entity.Property(e => e.FirstName).HasColumnName("firstname").HasColumnType("varchar(100)").IsRequired();
                entity.Property(e => e.LastName).HasColumnName("lastname").HasColumnType("varchar(100)").IsRequired();
                entity.Property(e => e.Dob).HasColumnName("dob").HasColumnType("date").IsRequired();
                entity.Property(e => e.Genre).HasColumnName("genre").HasColumnType("varchar(100)");
                entity.Property(e => e.Country).HasColumnName("country").HasColumnType("varchar(100)");
                entity.Property(e => e.CreatedDate).HasColumnName("createddate").HasColumnType("timestamp");
                entity.Property(e => e.LatestIssueDate).HasColumnName("latestissuedate").HasColumnType("timestamp");
            });

            // Artifacts table configuration
            modelBuilder.Entity<Artifact>(entity =>
            {
                entity.ToTable("artifacts");
                entity.Property(e => e.Id).HasColumnName("id");
                entity.Property(e => e.Name).HasColumnName("name").HasColumnType("varchar(100)").IsRequired();
                entity.Property(e => e.Description).HasColumnName("description").HasColumnType("text");
                entity.Property(e => e.Category).HasColumnName("category").HasColumnType("varchar(100)");
                entity.Property(e => e.CreatedDate).HasColumnName("createddate").HasColumnType("timestamp");
                entity.Property(e => e.ArtistId).HasColumnName("artistid").IsRequired();

                entity.HasOne(a => a.Artist)
                      .WithMany()
                      .HasForeignKey(a => a.ArtistId)
                      .HasConstraintName("artifacts_artistid_fkey");
            });

            // Users table configuration
            modelBuilder.Entity<User>(entity =>
            {
                entity.ToTable("users");
                entity.Property(e => e.Id).HasColumnName("id");
                entity.Property(e => e.FirstName).HasColumnName("firstname").HasColumnType("varchar(100)").IsRequired();
                entity.Property(e => e.LastName).HasColumnName("lastname").HasColumnType("varchar(100)").IsRequired();
                entity.Property(e => e.Email).HasColumnName("email").HasColumnType("varchar(255)").IsRequired();
                entity.Property(e => e.PasswordHash).HasColumnName("passwordhash").HasColumnType("varchar(255)").IsRequired();
                entity.Property(e => e.Description).HasColumnName("description").HasColumnType("text");
                entity.Property(e => e.Role).HasColumnName("role").HasColumnType("varchar(50)");
                entity.Property(e => e.CreatedDate).HasColumnName("createddate").HasColumnType("timestamp");
                entity.Property(e => e.ModifiedDate).HasColumnName("modifieddate").HasColumnType("timestamp");
            });
        }
    }
}
