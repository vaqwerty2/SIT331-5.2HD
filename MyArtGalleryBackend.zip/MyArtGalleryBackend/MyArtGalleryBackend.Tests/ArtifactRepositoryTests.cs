using Microsoft.EntityFrameworkCore;
using MyArtGalleryBackend.Data;
using MyArtGalleryBackend.Models;
using MyArtGalleryBackend.Repositories;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace MyArtGalleryBackend.Tests
{
    public class ArtifactRepositoryTests
    {
        private readonly DbContextOptions<ApplicationDbContext> _options;

        public ArtifactRepositoryTests()
        {
            _options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase_Artifact")
                .Options;

            using var context = new ApplicationDbContext(_options);
            context.Database.EnsureDeleted(); // Ensure the database is cleaned before each test run
            context.Database.EnsureCreated();
        }

        [Fact]
        public async Task AddArtifact_ShouldAddArtifact()
        {
            using var context = new ApplicationDbContext(_options);
            var repository = new ArtifactRepository(context);
            var artifact = new Artifact
            {
                Name = "Starry Night",
                Description = "A famous painting by Vincent van Gogh",
                Category = "Painting",
                CreatedDate = new System.DateTime(1889, 6, 1),
                ArtistId = 1
            };

            await repository.Add(artifact);
            var result = await context.Artifacts.FirstOrDefaultAsync(a => a.Name == "Starry Night");

            Assert.NotNull(result);
            Assert.Equal("Starry Night", result.Name);
        }

        [Fact]
        public async Task UpdateArtifact_ShouldModifyArtifact()
        {
            using var context = new ApplicationDbContext(_options);
            var repository = new ArtifactRepository(context);
            var artifact = new Artifact
            {
                Name = "Starry Night",
                Description = "A famous painting by Vincent van Gogh",
                Category = "Painting",
                CreatedDate = new System.DateTime(1889, 6, 1),
                ArtistId = 1
            };

            context.Artifacts.Add(artifact);
            await context.SaveChangesAsync(); // Ensure data is committed to the in-memory database

            artifact.Description = "An updated description";
            await repository.Update(artifact);
            var result = await context.Artifacts.FirstOrDefaultAsync(a => a.Id == artifact.Id);

            Assert.NotNull(result);
            Assert.Equal("An updated description", result.Description);
        }

        [Fact]
        public async Task DeleteArtifact_ShouldRemoveArtifact()
        {
            using var context = new ApplicationDbContext(_options);
            var repository = new ArtifactRepository(context);
            var artifact = new Artifact
            {
                Name = "Starry Night",
                Description = "A famous painting by Vincent van Gogh",
                Category = "Painting",
                CreatedDate = new System.DateTime(1889, 6, 1),
                ArtistId = 1
            };

            context.Artifacts.Add(artifact);
            await context.SaveChangesAsync(); // Ensure data is committed to the in-memory database

            await repository.Delete(artifact.Id);
            var result = await context.Artifacts.FirstOrDefaultAsync(a => a.Id == artifact.Id);

            Assert.Null(result);
        }
    }
}
