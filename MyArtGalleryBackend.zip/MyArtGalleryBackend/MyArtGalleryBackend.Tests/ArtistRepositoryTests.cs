using Microsoft.EntityFrameworkCore;
using MyArtGalleryBackend.Data;
using MyArtGalleryBackend.Models;
using MyArtGalleryBackend.Repositories;
using System.Linq;
using System.Threading.Tasks;
using Xunit;
using System.Collections.Generic;

namespace MyArtGalleryBackend.Tests
{
    public class ArtistRepositoryTests
    {
        private readonly DbContextOptions<ApplicationDbContext> _options;

        public ArtistRepositoryTests()
        {
            _options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase_Artist")
                .Options;

            using var context = new ApplicationDbContext(_options);
            context.Database.EnsureDeleted(); // Ensure the database is cleaned before each test run
            context.Database.EnsureCreated();
        }

        [Fact]
        public async Task AddArtist_ShouldAddArtist()
        {
            using var context = new ApplicationDbContext(_options);
            var repository = new ArtistRepository(context);
            var artist = new Artist
            {
                FirstName = "Vincent",
                LastName = "Van Gogh",
                Dob = new System.DateTime(1853, 3, 30),
                Country = "Netherlands",
                Genre = "Post-Impressionism"
            };

            await repository.Add(artist);
            var result = await context.Artists.FirstOrDefaultAsync(a => a.FirstName == "Vincent");

            Assert.NotNull(result);
            Assert.Equal("Vincent", result.FirstName);
        }

        [Fact]
        public async Task GetArtist_ShouldReturnArtist()
        {
            using var context = new ApplicationDbContext(_options);
            var repository = new ArtistRepository(context);
            var artist = new Artist
            {
                FirstName = "Vincent",
                LastName = "Van Gogh",
                Dob = new System.DateTime(1853, 3, 30),
                Country = "Netherlands",
                Genre = "Post-Impressionism"
            };

            context.Artists.Add(artist);
            await context.SaveChangesAsync();

            var result = await repository.GetById(artist.Id);

            Assert.NotNull(result);
            Assert.Equal("Vincent", result.FirstName);
        }

        [Fact]
        public async Task GetAllArtists_ShouldReturnAllArtists()
        {
            using var context = new ApplicationDbContext(_options);
            var repository = new ArtistRepository(context);
            var artist1 = new Artist
            {
                FirstName = "Vincent",
                LastName = "Van Gogh",
                Dob = new System.DateTime(1853, 3, 30),
                Country = "Netherlands",
                Genre = "Post-Impressionism"
            };
            var artist2 = new Artist
            {
                FirstName = "Pablo",
                LastName = "Picasso",
                Dob = new System.DateTime(1881, 10, 25),
                Country = "Spain",
                Genre = "Cubism"
            };

            context.Artists.Add(artist1);
            context.Artists.Add(artist2);
            await context.SaveChangesAsync();

            var result = await repository.GetAll();

            Assert.Equal(2, result.Count());
        }

        [Fact]
        public async Task UpdateArtist_ShouldModifyArtist()
        {
            using var context = new ApplicationDbContext(_options);
            var repository = new ArtistRepository(context);
            var artist = new Artist
            {
                FirstName = "Vincent",
                LastName = "Van Gogh",
                Dob = new System.DateTime(1853, 3, 30),
                Country = "Netherlands",
                Genre = "Post-Impressionism"
            };

            context.Artists.Add(artist);
            await context.SaveChangesAsync();

            artist.LastName = "UpdatedVanGogh";
            await repository.Update(artist);
            var result = await context.Artists.FirstOrDefaultAsync(a => a.Id == artist.Id);

            Assert.NotNull(result);
            Assert.Equal("UpdatedVanGogh", result.LastName);
        }

        [Fact]
        public async Task DeleteArtist_ShouldRemoveArtist()
        {
            using var context = new ApplicationDbContext(_options);
            var repository = new ArtistRepository(context);
            var artist = new Artist
            {
                FirstName = "Vincent",
                LastName = "Van Gogh",
                Dob = new System.DateTime(1853, 3, 30),
                Country = "Netherlands",
                Genre = "Post-Impressionism"
            };

            context.Artists.Add(artist);
            await context.SaveChangesAsync();

            await repository.Delete(artist.Id);
            var result = await context.Artists.FirstOrDefaultAsync(a => a.Id == artist.Id);

            Assert.Null(result);
        }
    }
}
