using Microsoft.EntityFrameworkCore;
using MyArtGalleryBackend.Data;
using MyArtGalleryBackend.Models;
using MyArtGalleryBackend.Repositories;
using System.Linq;
using System.Threading.Tasks;
using Xunit;
using System.Collections.Generic;

namespace MyArtGalleryBackend.Tests
{
    public class UserRepositoryTests
    {
        private readonly DbContextOptions<ApplicationDbContext> _options;

        public UserRepositoryTests()
        {
            _options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase_User")
                .Options;

            using var context = new ApplicationDbContext(_options);
            context.Database.EnsureDeleted(); // Ensure the database is cleaned before each test run
            context.Database.EnsureCreated();
        }

        [Fact]
        public async Task AddUser_ShouldAddUser()
        {
            using var context = new ApplicationDbContext(_options);
            var repository = new UserRepository(context);
            var user = new User
            {
                FirstName = "John",
                LastName = "Doe",
                Email = "testuser@example.com",
                Role = "Admin",
                PasswordHash = "hashed_password",
                Description = "Admin user"
            };

            await repository.Add(user);
            var result = await context.Users.FirstOrDefaultAsync(u => u.FirstName == "John");

            Assert.NotNull(result);
            Assert.Equal("John", result.FirstName);
        }

        [Fact]
        public async Task GetUser_ShouldReturnUser()
        {
            using var context = new ApplicationDbContext(_options);
            var repository = new UserRepository(context);
            var user = new User
            {
                FirstName = "John",
                LastName = "Doe",
                Role = "Admin",
                Email = "testuser@example.com",
                PasswordHash = "hashed_password",
                Description = "Admin user"
            };

            context.Users.Add(user);
            await context.SaveChangesAsync();

            var result = await repository.GetById(user.Id);

            Assert.NotNull(result);
            Assert.Equal("John", result.FirstName);
        }

        [Fact]
        public async Task GetAllUsers_ShouldReturnAllUsers()
        {
            using var context = new ApplicationDbContext(_options);
            var repository = new UserRepository(context);
            var user1 = new User
            {
                FirstName = "John",
                LastName = "Doe",
                Role = "Admin",
                Email = "testuser1@example.com",
                PasswordHash = "hashed_password",
                Description = "Admin user"
            };
            var user2 = new User
            {
                FirstName = "Jane",
                LastName = "Smith",
                Role = "User",
                Email = "testuser2@example.com",
                PasswordHash = "hashed_password",
                Description = "Regular user"
            };

            context.Users.Add(user1);
            context.Users.Add(user2);
            await context.SaveChangesAsync();

            var result = await repository.GetAll();

            Assert.Equal(2, result.Count());
        }

        [Fact]
        public async Task UpdateUser_ShouldModifyUser()
        {
            using var context = new ApplicationDbContext(_options);
            var repository = new UserRepository(context);
            var user = new User
            {
                FirstName = "John",
                LastName = "Doe",
                Role = "Admin",
                Email = "testuser@example.com",
                PasswordHash = "hashed_password",
                Description = "Admin user"
            };

            context.Users.Add(user);
            await context.SaveChangesAsync();

            user.LastName = "UpdatedDoe";
            await repository.Update(user);
            var result = await context.Users.FirstOrDefaultAsync(u => u.Id == user.Id);

            Assert.NotNull(result);
            Assert.Equal("UpdatedDoe", result.LastName);
        }

        [Fact]
        public async Task DeleteUser_ShouldRemoveUser()
        {
            using var context = new ApplicationDbContext(_options);
            var repository = new UserRepository(context);
            var user = new User
            {
                FirstName = "John",
                LastName = "Doe",
                Role = "Admin",
                Email = "testuser@example.com",
                PasswordHash = "hashed_password",
                Description = "Admin user"
            };

            context.Users.Add(user);
            await context.SaveChangesAsync();

            await repository.Delete(user.Id);
            var result = await context.Users.FirstOrDefaultAsync(u => u.Id == user.Id);

            Assert.Null(result);
        }
    }
}
